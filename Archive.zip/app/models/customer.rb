class Customer < ApplicationRecord

end
