require 'test_helper'

class JwtBlacklistTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
