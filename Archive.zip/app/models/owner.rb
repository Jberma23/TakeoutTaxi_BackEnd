class Owner < ApplicationRecord
end
