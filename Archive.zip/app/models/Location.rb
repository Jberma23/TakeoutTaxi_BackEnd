class Location < ApplicationRecord










  
end